package com.zhouwei.mzbannerview.remote;

/**
 * Created by zhouwei on 17/6/8.
 */

public class DataLoader {

}
