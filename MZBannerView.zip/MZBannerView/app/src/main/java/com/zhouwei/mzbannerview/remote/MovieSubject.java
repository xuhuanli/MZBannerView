package com.zhouwei.mzbannerview.remote;

import java.util.List;

/**
 * Created by zhouwei on 16/11/9.
 */

public class MovieSubject {
   public int count;
   public int start;
   public int total;
   public List<Movie> subjects;
   public String title;

}
