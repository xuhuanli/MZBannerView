package com.zhouwei.mzbannerview;

/**
 * Created by zhouwei on 17/5/31.
 */

public class DataEntry {
    public int resId;
    public String title;
    public String desc;
}
