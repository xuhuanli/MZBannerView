package com.zhouwei.mzbannerview;

/**
 * Created by zhouwei on 17/6/8.
 */

public class AppConfig {
    /**
     * 服务器地址，应该根据 DEBUG 判断选用哪个环境
     */
    public static final String BASE_URL = "https://api.douban.com/v2/movie/";
}
